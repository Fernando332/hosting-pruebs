class Auth {
  constructor() {
    this.user = JSON.parse(localStorage.getItem("user")) || null
  }

  isLoggedIn() {
    return !!this.user
  }

  login(email, password) {
    // Simulación de login
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (email && password) {
          const user = { id: "1", name: "Usuario Ejemplo", email }
          this.user = user
          localStorage.setItem("user", JSON.stringify(user))
          resolve(user)
        } else {
          reject(new Error("Credenciales inválidas"))
        }
      }, 1000)
    })
  }

  logout() {
    this.user = null
    localStorage.removeItem("user")
  }

  register(name, email, password) {
    // Simulación de registro
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (name && email && password) {
          const user = { id: "1", name, email }
          this.user = user
          localStorage.setItem("user", JSON.stringify(user))
          resolve(user)
        } else {
          reject(new Error("Datos de registro inválidos"))
        }
      }, 1000)
    })
  }
}

const auth = new Auth()

