import * as UI from "./ui.js"
import * as router from "./router.js"
import * as auth from "./auth.js"
import * as cart from "./cart.js"

document.addEventListener("DOMContentLoaded", () => {
  UI.displayHeader()
  UI.displayFooter()
  router.handleRoute()

  document.body.addEventListener("click", (e) => {
    if (e.target.tagName === "A") {
      e.preventDefault()
      router.navigate(e.target.getAttribute("href"))
    }
  })

  // Inicializar funcionalidad específica de la página
  const currentPage = window.location.pathname.split("/").pop()

  switch (currentPage) {
    case "login.html":
      initLoginPage()
      break
    case "registro.html":
      initRegisterPage()
      break
    case "panel-usuario.html":
      initUserPanelPage()
      break
    case "productos.html":
      initProductsPage()
      break
    // Añadir más casos según sea necesario
  }
})

function initLoginPage() {
  const loginForm = document.getElementById("login-form")
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const email = document.getElementById("email").value
      const password = document.getElementById("password").value
      try {
        await auth.login(email, password)
        UI.showMessage("Inicio de sesión exitoso")
        window.location.href = "panel-usuario.html"
      } catch (error) {
        UI.showMessage(error.message, "error")
      }
    })
  }
}

function initRegisterPage() {
  const registerForm = document.getElementById("register-form")
  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const name = document.getElementById("name").value
      const email = document.getElementById("email").value
      const password = document.getElementById("password").value
      const confirmPassword = document.getElementById("confirm-password").value

      if (password !== confirmPassword) {
        UI.showMessage("Las contraseñas no coinciden", "error")
        return
      }

      try {
        await auth.register(name, email, password)
        UI.showMessage("Registro exitoso")
        window.location.href = "panel-usuario.html"
      } catch (error) {
        UI.showMessage(error.message, "error")
      }
    })
  }
}

function initUserPanelPage() {
  if (!auth.isLoggedIn()) {
    window.location.href = "login.html"
    return
  }

  // Aquí puedes agregar la lógica para mostrar la información del usuario y sus servicios
}

function initProductsPage() {
  // Aquí puedes agregar la lógica para mostrar y manejar los productos
  const addToCartButtons = document.querySelectorAll(".add-to-cart")
  addToCartButtons.forEach((button) => {
    button.addEventListener("click", (e) => {
      const productId = e.target.getAttribute("data-id")
      const productName = e.target.getAttribute("data-name")
      const productPrice = Number.parseFloat(e.target.getAttribute("data-price"))

      cart.addItem({ id: productId, name: productName, price: productPrice })
      UI.showMessage(`${productName} añadido al carrito`)
      UI.displayHeader() // Actualizar el contador del carrito en el header
    })
  })
}

