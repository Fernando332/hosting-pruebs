import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function ProductosPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Nuestros Servicios de Hosting</h1>
      <div className="grid md:grid-cols-3 gap-8">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Hosting Web</h2>
          <p className="mb-4">Soluciones de hosting web rápidas y confiables para tu sitio.</p>
          <Link href="/productos/web">
            <Button>Ver Planes</Button>
          </Link>
        </div>
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Hosting Minecraft</h2>
          <p className="mb-4">Servidores de Minecraft de alto rendimiento para tu comunidad.</p>
          <Link href="/productos/minecraft">
            <Button>Ver Planes</Button>
          </Link>
        </div>
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Bots de Discord</h2>
          <p className="mb-4">Hosting para bots de Discord personalizados y eficientes.</p>
          <Link href="/productos/discord">
            <Button>Ver Planes</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

