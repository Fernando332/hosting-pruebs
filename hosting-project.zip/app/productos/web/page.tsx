import HostingPlan from "@/components/hosting-plan"

const planesWeb = [
  {
    id: "web-basico",
    name: "Básico",
    price: 9.99,
    description: "Perfecto para sitios web personales",
    features: ["1 Sitio Web", "10 GB de Almacenamiento", "Ancho de Banda Sin Límites", "SSL Gratis"],
  },
  {
    id: "web-profesional",
    name: "Profesional",
    price: 19.99,
    description: "Ideal para pequeñas empresas",
    features: ["5 Sitios Web", "50 GB de Almacenamiento", "Ancho de Banda Sin Límites", "SSL Gratis", "Dominio Gratis"],
  },
  {
    id: "web-empresarial",
    name: "Empresarial",
    price: 39.99,
    description: "Para empresas en crecimiento",
    features: [
      "Sitios Web Ilimitados",
      "100 GB de Almacenamiento",
      "Ancho de Banda Sin Límites",
      "SSL Gratis",
      "Dominio Gratis",
      "IP Dedicada",
    ],
  },
]

export default function HostingWebPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Planes de Hosting Web</h1>
      <div className="grid md:grid-cols-3 gap-8">
        {planesWeb.map((plan) => (
          <HostingPlan key={plan.id} {...plan} />
        ))}
      </div>
    </div>
  )
}

