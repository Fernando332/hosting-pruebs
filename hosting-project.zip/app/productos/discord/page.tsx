import HostingPlan from "@/components/hosting-plan"

const planesDiscord = [
  {
    id: "discord-basico",
    name: "Bot Básico",
    price: 9.99,
    description: "Perfecto para bots pequeños y personales",
    features: [
      "512 MB de RAM",
      "5 GB de Almacenamiento",
      "Soporte para 1 Bot",
      "Uptime 99.9%",
      "Panel de Control Básico",
    ],
  },
  {
    id: "discord-avanzado",
    name: "Bot Avanzado",
    price: 19.99,
    description: "Ideal para bots de comunidades medianas",
    features: [
      "1 GB de RAM",
      "10 GB de Almacenamiento",
      "Soporte para 3 Bots",
      "Uptime 99.9%",
      "Panel de Control Avanzado",
      "Copias de Seguridad Diarias",
    ],
  },
  {
    id: "discord-pro",
    name: "Bot Pro",
    price: 39.99,
    description: "Para bots de gran escala y alto rendimiento",
    features: [
      "2 GB de RAM",
      "20 GB de Almacenamiento",
      "Soporte para 5 Bots",
      "Uptime 99.99%",
      "Panel de Control Personalizado",
      "Copias de Seguridad Automáticas",
      "Soporte Prioritario 24/7",
      "Escalado Automático",
    ],
  },
]

export default function HostingDiscordPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Planes de Hosting para Bots de Discord</h1>
      <div className="grid md:grid-cols-3 gap-8">
        {planesDiscord.map((plan) => (
          <HostingPlan key={plan.id} {...plan} />
        ))}
      </div>
    </div>
  )
}

