import HostingPlan from "@/components/hosting-plan"

const planesMinecraft = [
  {
    id: "mc-basico",
    name: "Servidor Básico",
    price: 14.99,
    description: "Ideal para pequeños grupos de amigos",
    features: [
      "2 GB de RAM",
      "20 Slots de Jugadores",
      "10 GB de Almacenamiento SSD",
      "Panel de Control Intuitivo",
      "Copias de Seguridad Diarias",
    ],
  },
  {
    id: "mc-premium",
    name: "Servidor Premium",
    price: 29.99,
    description: "Perfecto para comunidades medianas",
    features: [
      "4 GB de RAM",
      "50 Slots de Jugadores",
      "30 GB de Almacenamiento SSD",
      "Panel de Control Avanzado",
      "Copias de Seguridad Diarias",
      "Dominio Personalizado",
    ],
  },
  {
    id: "mc-ultra",
    name: "Servidor Ultra",
    price: 49.99,
    description: "Para grandes comunidades y servidores populares",
    features: [
      "8 GB de RAM",
      "100 Slots de Jugadores",
      "50 GB de Almacenamiento SSD",
      "Panel de Control Personalizado",
      "Copias de Seguridad Automáticas",
      "Dominio Personalizado",
      "Soporte Prioritario 24/7",
      "Instalación de Mods Asistida",
    ],
  },
]

export default function HostingMinecraftPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Planes de Hosting Minecraft</h1>
      <div className="grid md:grid-cols-3 gap-8">
        {planesMinecraft.map((plan) => (
          <HostingPlan key={plan.id} {...plan} />
        ))}
      </div>
    </div>
  )
}

