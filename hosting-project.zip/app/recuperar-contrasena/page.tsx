import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function RecuperarContrasenaPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-center mb-6">Recuperar Contraseña</h1>
        <form className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Correo Electrónico</Label>
            <Input id="email" type="email" placeholder="tu@email.com" required />
          </div>
          <Button type="submit" className="w-full">
            Enviar Instrucciones
          </Button>
        </form>
        <p className="text-center mt-4 text-sm text-muted-foreground">
          Te enviaremos instrucciones para restablecer tu contraseña.
        </p>
      </div>
    </div>
  )
}

