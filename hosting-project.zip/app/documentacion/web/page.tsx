import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function DocumentacionWebPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Documentación de Hosting Web</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Primeros Pasos</CardTitle>
            <CardDescription>Cómo comenzar con tu hosting web</CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal list-inside space-y-2">
              <li>Inicia sesión en tu panel de control</li>
              <li>Crea tu primer sitio web</li>
              <li>Sube tus archivos mediante FTP o el administrador de archivos</li>
              <li>Configura tu dominio</li>
              <li>¡Tu sitio web está en línea!</li>
            </ol>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Gestión de Bases de Datos</CardTitle>
            <CardDescription>Cómo trabajar con bases de datos MySQL</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2">
              <li>Accede a phpMyAdmin desde tu panel de control</li>
              <li>Crea una nueva base de datos</li>
              <li>Gestiona usuarios y permisos</li>
              <li>Importa y exporta datos</li>
              <li>Optimiza el rendimiento de tu base de datos</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

