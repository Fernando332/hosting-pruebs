import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function DocumentacionDiscordPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Documentación de Hosting para Bots de Discord</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Despliegue de tu Bot</CardTitle>
            <CardDescription>Cómo poner en marcha tu bot de Discord</CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal list-inside space-y-2">
              <li>Sube el código de tu bot al servidor</li>
              <li>Configura las variables de entorno necesarias</li>
              <li>Instala las dependencias requeridas</li>
              <li>Inicia tu bot usando el panel de control</li>
              <li>Verifica que tu bot esté en línea en Discord</li>
            </ol>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Mantenimiento y Monitoreo</CardTitle>
            <CardDescription>Cómo mantener tu bot funcionando sin problemas</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2">
              <li>Configura alertas de uso de recursos</li>
              <li>Revisa los logs del bot regularmente</li>
              <li>Actualiza las dependencias cuando sea necesario</li>
              <li>Realiza copias de seguridad periódicas</li>
              <li>Monitorea el rendimiento y escala según sea necesario</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

