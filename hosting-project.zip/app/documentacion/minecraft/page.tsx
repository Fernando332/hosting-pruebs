import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function DocumentacionMinecraftPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Documentación de Hosting Minecraft</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Configuración del Servidor</CardTitle>
            <CardDescription>Cómo configurar tu servidor de Minecraft</CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal list-inside space-y-2">
              <li>Accede al panel de control de tu servidor</li>
              <li>Selecciona la versión de Minecraft que deseas usar</li>
              <li>Configura las opciones básicas del servidor (modo de juego, dificultad, etc.)</li>
              <li>Establece el límite de jugadores y la memoria RAM</li>
              <li>Inicia tu servidor y conéctate usando la IP proporcionada</li>
            </ol>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Instalación de Mods y Plugins</CardTitle>
            <CardDescription>Cómo personalizar tu experiencia de juego</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2">
              <li>Accede al administrador de archivos de tu servidor</li>
              <li>Sube los archivos de mods o plugins a las carpetas correspondientes</li>
              <li>Configura los archivos de configuración según sea necesario</li>
              <li>Reinicia tu servidor para aplicar los cambios</li>
              <li>Verifica que los mods o plugins estén funcionando correctamente</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

