"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/components/auth-provider"

export default function PanelUsuarioPage() {
  const [activeTab, setActiveTab] = useState("perfil")
  const { user } = useAuth()

  const serviciosActivos = [
    { id: 1, tipo: "Hosting Web", nombre: "Mi Sitio Web", estado: "Activo" },
    { id: 2, tipo: "Servidor Minecraft", nombre: "Servidor Survival", estado: "Activo" },
    { id: 3, tipo: "Bot Discord", nombre: "MusicBot", estado: "Inactivo" },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Panel de Usuario</h1>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="servicios">Mis Servicios</TabsTrigger>
          <TabsTrigger value="facturacion">Facturación</TabsTrigger>
        </TabsList>
        <TabsContent value="perfil">
          <Card>
            <CardHeader>
              <CardTitle>Información del Perfil</CardTitle>
              <CardDescription>Gestiona tu información personal</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium">
                    Nombre
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    defaultValue={user?.name}
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium">
                    Correo Electrónico
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    defaultValue={user?.email}
                  />
                </div>
                <Button type="submit">Actualizar Perfil</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="servicios">
          <Card>
            <CardHeader>
              <CardTitle>Mis Servicios Activos</CardTitle>
              <CardDescription>Gestiona tus servicios de hosting</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {serviciosActivos.map((servicio) => (
                  <li key={servicio.id} className="border-b pb-4">
                    <p className="font-semibold">{servicio.nombre}</p>
                    <p>Tipo: {servicio.tipo}</p>
                    <p>Estado: {servicio.estado}</p>
                    <Button variant="outline" className="mt-2">
                      Gestionar
                    </Button>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="facturacion">
          <Card>
            <CardHeader>
              <CardTitle>Información de Facturación</CardTitle>
              <CardDescription>Gestiona tus métodos de pago y facturación</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Método de Pago Actual</h3>
                  <p>Tarjeta terminada en 1234</p>
                  <Button variant="outline" className="mt-2">
                    Cambiar Método de Pago
                  </Button>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Dirección de Facturación</h3>
                  <p>123 Calle Principal, Ciudad, País, CP 12345</p>
                  <Button variant="outline" className="mt-2">
                    Actualizar Dirección
                  </Button>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Historial de Facturas</h3>
                  <ul className="space-y-2">
                    <li>Factura #1001 - $49.99 - 01/05/2024</li>
                    <li>Factura #1002 - $49.99 - 01/04/2024</li>
                    <li>Factura #1003 - $49.99 - 01/03/2024</li>
                  </ul>
                  <Button variant="outline" className="mt-2">
                    Ver Todas las Facturas
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

