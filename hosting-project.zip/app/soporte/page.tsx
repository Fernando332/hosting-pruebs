import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

export default function SoportePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Soporte</h1>
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Contáctanos</h2>
          <form className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nombre</Label>
              <Input id="name" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Correo Electrónico</Label>
              <Input id="email" type="email" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="message">Mensaje</Label>
              <Textarea id="message" required />
            </div>
            <Button type="submit">Enviar Mensaje</Button>
          </form>
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-4">Preguntas Frecuentes</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">¿Cómo puedo cambiar mi plan?</h3>
              <p>
                Puedes cambiar tu plan en cualquier momento desde tu panel de usuario. Ve a la sección "Planes" y
                selecciona el nuevo plan que deseas.
              </p>
            </div>
            <div>
              <h3 className="font-semibold">¿Ofrecen reembolsos?</h3>
              <p>Sí, ofrecemos una garantía de devolución de dinero de 30 días en todos nuestros planes de hosting.</p>
            </div>
            <div>
              <h3 className="font-semibold">¿Cómo puedo migrar mi sitio web a HostPro?</h3>
              <p>
                Ofrecemos migración gratuita para todos los nuevos clientes. Nuestro equipo de soporte te ayudará a
                migrar tu sitio web sin problemas.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

